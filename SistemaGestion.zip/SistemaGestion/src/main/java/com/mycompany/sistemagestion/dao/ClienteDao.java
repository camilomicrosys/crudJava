/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemagestion.dao;

import com.mycompany.sistemagestion.models.Cliente;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lenovo
 */
public class ClienteDao {
    
      
    
    //conexion a base de datos e insercion le decimos que pueda recibir parametros de tipo cliente
    
    public Connection conex(){
    String db="java";
    String usuario="root";
    String pass="";
    String host="localhost";
    String puerto="3306";
    String driver="com.mysql.jdbc.Driver";
    String conexion_url="jdbc:mysql://"+host+":"+puerto+"/"+db+"?useSSL=false";
    Connection conexion=null;
        try {
        Class.forName(driver);
        //probamos la conexion a la db
        conexion = DriverManager.getConnection(conexion_url,usuario,pass);
        //accedemos a los metodos que creamos en la clase cliente
       
        } catch (Exception ex) {
            Logger.getLogger(ClienteDao.class.getName()).log(Level.SEVERE, null, ex);
        }
          
        
      
        return conexion;
        
    }
    public void crear(Cliente cliente){
    
      
        try {
         //aca llamamos la funcion inicial que hicimos de la conexion
        Connection conexion=conex();
        //accedemos a los metodos que creamos en la clase cliente
        String query="INSERT INTO `clientes` (`id`, `nombre`, `apellido`, `telefono`, `email`) VALUES (NULL, '"+cliente.getNombre()+"', '"+cliente.getApellido()+"', '"+cliente.getTelefono()+"', '"+cliente.getEmail()+"');";
        Statement statement= conexion.createStatement();
        statement.execute(query);
        } catch (Exception ex) {
            Logger.getLogger(ClienteDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
      
        
        
    }
    //para retornar los clientes retornamos una tipo lista de typo cliente
    public List<Cliente> listar(){
      
    //una variable tipo list clientes para guardar el resultado de la db
     List<Cliente>listado=new ArrayList<>();
     
        try {
         //aca llamamos la funcion inicial que hicimos de la conexion
        Connection conexion=conex();
        //accedemos a los metodos que creamos en la clase cliente
        String query="SELECT * FROM `clientes`";
        Statement statement= conexion.createStatement();
        //para obtener datos no tiramos el wxcute sino el executeQuery y creamos una variable de tipo result set para guardar los datos
        ResultSet resultado= statement.executeQuery(query);
            //recorremos cada fila de la db
            while (resultado.next()) {
               Cliente cliente=new Cliente();
               //empezams a setear los valores de los clientes obteniendo cada columna de la db y asignandola a clientes en su propiedad seter
               //el get string es propio de mysql para obtener el dato con nombre de columna
               cliente.setId(resultado.getString("id"));
               cliente.setNombre(resultado.getString("nombre"));
               cliente.setApellido(resultado.getString("apellido"));
               cliente.setTelefono(resultado.getString("telefono"));
               cliente.setEmail(resultado.getString("email"));
               //ahora cogemos el array lista y le hacemos un array push por cada vuelta donde cliente es el objeto con todo lo que hemos seteado
               listado.add(cliente);
               
            }
        
        } catch (Exception ex) {
            Logger.getLogger(ClienteDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        //este listado es la variable que se creo arriba en esta funcion de tipo lista de clientes y es la que almacenara internamente el contenido de la variable resultado
        return listado;
       
    }
    
    public void Eliminar(String id){
        try {
         //aca llamamos la funcion inicial que hicimos de la conexion
        Connection conexion=conex();
        //accedemos a los metodos que creamos en la clase cliente
        String query="DELETE FROM `clientes` WHERE `clientes`.`id` = "+id;
        Statement statement= conexion.createStatement();
        statement.execute(query);
        } catch (Exception ex) {
            Logger.getLogger(ClienteDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    //actualizamos el cliente
    public void actualizar(Cliente cliente){
        
         try {
         //aca llamamos la funcion inicial que hicimos de la conexion
        Connection conexion=conex();
        //accedemos a los metodos que creamos en la clase cliente
        String query="UPDATE `clientes` SET `nombre` = '"+cliente.getNombre()+"',`apellido` = '"+cliente.getApellido()+"',`telefono` = '"+cliente.getTelefono()+"',`email` = '"+cliente.getEmail()+"' WHERE `clientes`.`id` = '"+cliente.getId()+"';";
        Statement statement= conexion.createStatement();
        statement.execute(query);
        } catch (Exception ex) {
            Logger.getLogger(ClienteDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}

