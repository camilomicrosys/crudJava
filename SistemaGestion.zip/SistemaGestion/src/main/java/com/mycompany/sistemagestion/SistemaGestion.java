/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemagestion;

import com.mycompany.sistemagestion.vistas.Formulariogestion;
import java.net.ContentHandlerFactory;

/**
 *
 * @author Lenovo
 */
public class SistemaGestion {

    public static void main(String[] args) {
        
        //esto es para motrar el formulario
        Formulariogestion ventana= new Formulariogestion();
       ventana.show();

        
       
        
       
        
       
          
         
        
    }
}
